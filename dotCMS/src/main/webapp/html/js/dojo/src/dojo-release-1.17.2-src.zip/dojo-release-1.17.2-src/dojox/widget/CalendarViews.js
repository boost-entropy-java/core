define([
	"dojo/_base/kernel"
], function(kernel){
	kernel.experimental("dojox/widget/CalendarViews");
	return {};
});
