define(['./wire/_base'],function(){
	/*=====
	 return {
	 // summary:
	 //		Deprecated.  Should require dojox/wire modules directly rather than trying to access them through
	 //		this module.
	 };
	 =====*/
});
