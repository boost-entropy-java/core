define(['./storage/_common'],function(){
	/*=====
	 return {
	 // summary:
	 //		Deprecated.  Should require dojox/storage modules directly rather than trying to access them through
	 //		this module.
	 };
	 =====*/
});
