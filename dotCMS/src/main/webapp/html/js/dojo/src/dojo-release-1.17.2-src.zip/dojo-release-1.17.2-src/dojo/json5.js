define([
	'./json5/parse'
], function (parse) {
	return {
		parse: parse
	};
});
