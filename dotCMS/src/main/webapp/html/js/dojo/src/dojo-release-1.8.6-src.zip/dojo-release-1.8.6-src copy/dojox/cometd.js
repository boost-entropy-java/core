// TODO: Replace with version from CometD project
// stub loader for the cometd module since no implementation code is allowed to live in top-level files
