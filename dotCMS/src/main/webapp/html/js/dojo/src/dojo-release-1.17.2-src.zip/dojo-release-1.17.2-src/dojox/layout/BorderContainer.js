dojo.provide("dojox.layout.BorderContainer");

console.error("dojox.layout.BorderContainer moved to dijit.layout.BorderContainer");