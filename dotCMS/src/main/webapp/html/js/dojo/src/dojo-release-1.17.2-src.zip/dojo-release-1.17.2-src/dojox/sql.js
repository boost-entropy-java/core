define(['./sql/_base'],function(){
	/*=====
	 return {
	 // summary:
	 //		Deprecated.  Should require dojox/sql modules directly rather than trying to access them through
	 //		this module.
	 };
	 =====*/
});
