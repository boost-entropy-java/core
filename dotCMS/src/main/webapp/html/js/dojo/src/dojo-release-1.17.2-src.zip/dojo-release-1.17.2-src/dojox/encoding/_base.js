define(['dojo/_base/lang'], function(lang){
	return lang.getObject("dojox.encoding._base", true);
});
