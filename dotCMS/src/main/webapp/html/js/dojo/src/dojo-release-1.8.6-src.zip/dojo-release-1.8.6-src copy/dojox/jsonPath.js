define(['./jsonPath/query'],function(){
	/*=====
	 return {
	 // summary:
	 //		Deprecated.  Should require dojox/jsonPath modules directly rather than trying to access them through
	 //		this module.
	 };
	 =====*/
});
