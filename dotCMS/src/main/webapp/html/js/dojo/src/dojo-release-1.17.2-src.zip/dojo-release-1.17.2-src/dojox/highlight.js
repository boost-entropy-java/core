define(["./highlight/_base"], function(highlight){
	/*=====
	 return {
	 // summary:
	 //		Deprecated.  Should require dojox/highlight modules directly rather than trying to access them through
	 //		this module.
	 };
	 =====*/
	return highlight;
});
